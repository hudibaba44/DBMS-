1. The functions for app.py is in hotelhistory.py. just include the whole file and remove the previous definition of these functions.
2. hotelhistory.html and hotelhistorycancellation.html needs to be put in templates folder
